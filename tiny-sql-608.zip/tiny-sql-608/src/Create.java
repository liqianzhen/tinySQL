import storageManager.*;

import java.util.ArrayList;

public class Create {
	

	public Relation createRelation(Statement statement, Base base){
		MainMemory mm = base.mm;
		Disk disk = base.disk;
		SchemaManager sm = base.sm;
		
		ArrayList<Node> nodes = statement.getNodes();
		
		String relation_name = nodes.get(0).getLabel();
		
		ArrayList<Node> list = nodes.get(1).getChildren();
		
		ArrayList<String> field_names = new ArrayList<String>();
		ArrayList<FieldType> field_types = new ArrayList<FieldType>();


		for (Node x : list) {
			String[] temp = x.getLabel().split(",");
			field_names.add(temp[0]);
			if (temp[1].equalsIgnoreCase("INT")) {
				field_types.add(FieldType.INT);
			} else {
				field_types.add(FieldType.STR20);
			}
		}

		Schema schema = new Schema(field_names, field_types);
		Relation r = sm.createRelation(relation_name, schema);
		return r;
	}
	
	


}
