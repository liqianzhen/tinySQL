package storageManager;

/* A field type can either be INT or STR20
 * Usage: When you specify the schema, you need the following definition of field types.
 */

public enum FieldType {
	INT, STR20
}
