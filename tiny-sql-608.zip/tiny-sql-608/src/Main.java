import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Base base = new Base();
        Main sql = new Main();
        File file = sql.getFile("text.txt");

        //construct the Executor
        try (Scanner scanner = new Scanner(file)) {
            int i = 0;
            while (scanner.hasNextLine()) {
            	i++;
            	System.out.println("this is the number of line+ " + i);
                //deal with every line
                String line = scanner.nextLine();
                //parse every statement
                Parser parser = new Parser();
                Statement statement = parser.parse(line);

                if(line.split(" ")[0].equalsIgnoreCase("create")) {
                    Create create_executor = new Create();
                    create_executor.createRelation(statement, base);
                } else if (line.split(" ")[0].equalsIgnoreCase("drop")) {
                    Drop drop_executor = new Drop();
                    drop_executor.dropRelation(statement, base);
                } else if (line.split(" ")[0].equalsIgnoreCase("insert")) {
                    Insert insert = new Insert();
                    insert.insertTuple(statement, base);
                } else if (line.split(" ")[0].equalsIgnoreCase("select")) {
                    Selection select = new Selection();
                    select.select(statement, base);
                }
                
            }

            scanner.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private File getFile(String fileName) {
        //Get file from resources folder
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(fileName).getFile());
        return file;
    }
}
