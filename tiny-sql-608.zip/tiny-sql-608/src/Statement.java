import java.util.ArrayList;

public class Statement {
	
	private ArrayList<Node> nodes;
	
	// a series of boolean function to check whether it is a create cluase
	public Statement(){
		nodes = new ArrayList<Node>();
	}
	
	public Statement(ArrayList<Node> nodes){
		this.nodes = nodes;
	}
	
	
	public ArrayList<Node> getNodes(){
		return this.nodes;
	}

}
