import java.util.ArrayList;

public class Node {
	private String label;
	private ArrayList<Node> children;
	
	
	public Node(String label, ArrayList<Node> children) {
		super();
		this.label = label;
		this.children = children;
	}


	public String getLabel() {
		return label;
	}


	public void setLabel(String label) {
		this.label = label;
	}


	public ArrayList<Node> getChildren() {
		return children;
	}


	public void setChildren(ArrayList<Node> children) {
		this.children = children;
	}
	
	
	

}
