CSCE- 608 Database System
Course Project #2 

Run Project
----------------------------------
Run the main class to get the output, you can put the sql queries in the text.txt and we put the result in the output.txt file.

Run the Tools class to get the result of running time and the number of disk I/O's we used. Put the sql queries in the RunningTime.txt file,
you will see the running time and the number of disk I/O's in the console.

Thank you. Have fun!