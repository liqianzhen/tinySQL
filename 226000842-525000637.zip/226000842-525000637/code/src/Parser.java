import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

public class Parser {
	
	static HashMap<String,Integer> keyWords = new HashMap<String, Integer>();
	
    public Parser() {
    	keyWords.put("OR", 0);
    	keyWords.put("AND",1);
    	keyWords.put("ANDNOT",1);
    	keyWords.put("=", 2);
    	keyWords.put(">", 2);
    	keyWords.put("<", 2);
    	keyWords.put("+", 3);
    	keyWords.put("-", 3);
    	keyWords.put("*", 4);
    	keyWords.put("/", 4);
    }
    
    public static Statement parse(String s){
    	String[] strs = s.split(" ");
    	String cur = strs[0];
    	if(cur.equalsIgnoreCase("CREATE")){
    		return parseCreate(s);
    	}
    	else if(cur.equalsIgnoreCase("Drop")){
    		return parseDrop(s);
    	}
		else if(cur.equalsIgnoreCase("insert")){
			return parseInsert(s);	
		}
		else if(cur.equalsIgnoreCase("delete")){
			return parseDelete(s);
		}
		else if(cur.equalsIgnoreCase("select")){
			return parseSelect(s);
		}
    	return null;
    }
	
	public static Statement parseCreate(String s){
		String[] strs = s.split(" ");
		Node name = new Node(strs[2],new ArrayList<Node>());
		ArrayList<Node> children = new ArrayList<Node>();
		
		for(int i = 3; i < strs.length; i+=2){
			String label = "";
			if(i == 3){
				label = strs[i].substring(1) + "," + strs[i+1].substring(0, strs[i+1].length()-1);
			} else if(i == strs.length-2){
				// bugs: here lacks of else
				label = strs[i] + "," + strs[i+1].substring(0, strs[i+1].length()-1);
			}
			else{
				label = strs[i] + "," + strs[i+1].substring(0, strs[i+1].length()-1);
			}
			
			Node atrr = new Node(label,new ArrayList<Node>());
			children.add(atrr);
			
		}
		
		Node attribute_list = new Node("atrribute_list",children);
		
		ArrayList<Node> nodes = new ArrayList<Node>();
		nodes.add(name);
		nodes.add(attribute_list);
		Statement statement = new Statement(nodes);
		return statement;
	}
	
	
	public static Statement parseDrop(String s){
		String[] strs = s.split(" ");
		Node name = new Node(strs[2],new ArrayList<Node>());
		ArrayList<Node> nodes = new ArrayList<Node>();
		nodes.add(name);
		Statement statement = new Statement(nodes);
		return statement;
	}
	
	public static Statement parseInsert(String s){
		// INSERT INTO course (sid, homework, project, exam, grade) VALUES (2, NULL, 100, 100, "E")
		String[] strs = s.split(" ");
		Node name = new Node(strs[2],new ArrayList<Node>());
		int index = 3;

		//get attribute list
		ArrayList<Node> children = new ArrayList<Node>();
		while(!strs[index+1].equalsIgnoreCase("VALUES") && !strs[index+1].equalsIgnoreCase("SELECT")){
			String label = "";

			if(index == 3){
				label = strs[index].substring(1,strs[index].length()-1);
			}
			else{
				label = strs[index].substring(0, strs[index].length()-1);
			}

			Node atrr = new Node(label,new ArrayList<Node>());
			children.add(atrr);
			index++;
		}

		String label = strs[index].substring(0, strs[index].length()-1);
		//insert single value bug
		if (label.charAt(0) == '(') {
			label = label.substring(1);
		}
		Node atrr = new Node(label,new ArrayList<Node>());
		children.add(atrr);
		Node attribute_list = new Node("atrribute_list",children);

		//get value list
		//create root node
		ArrayList<Node> nodes = new ArrayList<Node>();
		nodes.add(name);
		nodes.add(attribute_list);
		if (strs[index + 1].equalsIgnoreCase("VALUES")) {
			//one tuple a time
			ArrayList<Node> values = new ArrayList<Node>();
			index += 2;
			label = strs[index].substring(1, strs[index].length() - 1);
			values.add(new Node(label,new ArrayList<Node>()));
			index++;
			while(index < strs.length-1){
				label = strs[index].substring(0, strs[index].length() - 1);
				values.add(new Node(label,null));
				index++;
			}
			if (index < strs.length) {
				label = strs[index].substring(0,strs[index].length()-1);
				values.add(new Node(label,null));
			}
			Node insert_tuple = new Node("insert_tuple",values);
			nodes.add(insert_tuple);
		} else {
			// insert multiple tuples a time through select
			String subquery = s.substring(s.indexOf("SELECT"));
			Statement substatment = parseSelect(subquery);
			Node selet_subquery = new Node("select_subquery", substatment.getNodes());
			nodes.add(selet_subquery);
		}

		Statement statement = new Statement(nodes);
		return statement;
	}
	
	
	public static Statement parseDelete(String s){
		//DELETE FROM course WHERE grade = "E"
		String[] strs = s.split(" ");
		Node relation_name = new Node(strs[2],null);
		ArrayList<Node> children = new ArrayList<Node>();
		children.add(relation_name);
		
		if(strs.length > 3){
			// contains where clause;
			String next = "";
			int index = 3;
			while(index < strs.length){
				next += strs[index] + " ";
				index++;
			}
			next = next.substring(0, next.length()-1);
			Node tmp = parseWhere(next);
			children.add(tmp);
		}
		Statement statement = new Statement(children);
		return statement;
	}
	
	public static Statement parseSelect(String s){
		//SELECT * FROM course, course2 WHERE course.sid = course2.sid ORDER BY course.exam
		int index_from = s.indexOf("FROM");
		String select_item = s.substring(7, index_from);
		String from_item = "";
		String where_item = "";
		String order_item = "";

		int index_where = s.indexOf("WHERE");
		int index_order = s.indexOf("ORDER");
		
		ArrayList<Node> children = new ArrayList<Node>();
		// select items;
		ArrayList<Node> selectNodes = new ArrayList<Node>();
		String[] strs = select_item.split(" ");
		int index = 0;
		if(strs[0].equalsIgnoreCase("distinct")){
			Node cur = new Node("distinct",null);
			index++;
			//didn't add this distinct to selectNodes
			selectNodes.add(cur);
		}
		while(index < strs.length-1){
			Node cur = new Node(strs[index].substring(0,strs[index].length()-1),null);
			selectNodes.add(cur);
			index++;
		}
		Node cur = new Node(strs[index],null);
		selectNodes.add(cur);
		Node node = new Node("select_items",selectNodes);
		
		children.add(node);
		// from
		if(index_where == -1){
			//change here for case "SELECT * FROM course ORDER BY exam"
			if (index_order == -1) {
				from_item = s.substring(index_from + 5);
			} else {
				from_item = s.substring(index_from + 5, index_order - 1);
			}
		}
		else{
			from_item = s.substring(index_from + 5, index_where);
		}
		Node from_items = parseFrom(from_item);
		children.add(from_items);
		
		// where
		if(index_where != -1){
			if(index_order == -1){
				where_item = s.substring(index_where + 6);
			}
			else{
				where_item = s.substring(index_where + 6,index_order);
			}
		}
		if(where_item.length() > 0){
			Node where_items = parseWhere(where_item);
			children.add(where_items);
		}

		//order
		if(index_order != -1){
			order_item = s.substring(index_order+ 9);
		}
		if(order_item.length() > 0){
			// this is a bug not parseWhere but parseOrder
			Node order_items = parseOrder(order_item);
			children.add( order_items);
		}
		return new Statement(children);
	}
	
	public static Node parseFrom(String s){
		//course, course2
		ArrayList<Node> children = new ArrayList<Node>();

		String[] strs = s.split(",");
		for(int i = 0 ; i < strs.length; i++){
			//the last term has " ", add trim() function
			Node cur = new Node(strs[i].trim(),null);
			children.add(cur);
		}
		Node node = new Node("from_list",children);
		return node;
		
	}
	
	public  static Node parseOrder(String s){
		//this is another bug, not [2], but [0]
		String order = s.split(" ")[0];
		Node node = new Node(order, null);
		ArrayList<Node> children = new ArrayList<Node>();
		children.add(node);
		Node ans = new Node("order_list",children);
		return ans;
		
	}
	
	
	public static Node parseWhere(String s){
	  	keyWords.put("OR", 0);
    	keyWords.put("AND",1);
    	keyWords.put("ANDNOT",1);
    	keyWords.put("=", 2);
    	keyWords.put(">", 2);
    	keyWords.put("<", 2);
    	keyWords.put("+", 3);
    	keyWords.put("-", 3);
    	keyWords.put("*", 4);
    	keyWords.put("/", 4);
    	
		Stack<Node> stack = new Stack<Node>();
		
		String[] strs = s.split(" ");
		
		for(int i = 0 ; i < strs.length; i++){
			
            if (keyWords.containsKey(strs[i]))
            {
            	String key = strs[i];
            	if(key.equals("AND") && strs[i+1].equals("NOT")){
            		key += "NOT";
            		i++;
            	}
                if(stack.size() >= 3)
                {
                    Node last = stack.pop();
                    if(keyWords.get(key) > keyWords.get(stack.peek().getLabel()))
                    {
                        stack.push(last);
                        stack.push(new Node(key,new ArrayList<Node>()));
                    }
                    else
                    {
                        while (stack.size()>0 && keyWords.get(key) <= keyWords.get(stack.peek().getLabel()))
                        {
                            Node operation = stack.pop();
                            
                            Node num2 = stack.pop();
                            operation.getChildren().add(last);
                            operation.getChildren().add(num2);
                            last = operation;
                        }
                        
                        stack.push(last);
                        stack.push(new Node(key,new ArrayList<Node>()));
                    }
                }
                else
                {
                	
                    stack.push(new Node(key,new ArrayList<Node>()));
                }
            }
			else if(strs[i].equals("[") ){
				int index = i+1;
				String tmp = "";
				while(!strs[index].equals("]")){
					tmp += strs[index] + " ";
					index++;
				}
				Node cur = parseWhere(tmp);
				stack.push(cur);
			
				i = index;
	
			}
			else if(strs[i].equals("(")){
				
				int index = i+1;
				String tmp = "";
				while(!strs[index].equals(")")){
					tmp += strs[index] + " ";
					index++;
				}
				Node cur = parseWhere(tmp);
				stack.push(cur);
				i = index;
			}
			else if(strs[i].equals("NOT")){
				stack.push(new Node("NOT", new ArrayList<Node>()));
			}
			else if(Character.isDigit(strs[i].charAt(0))){
				Node ch = new Node(strs[i],new ArrayList<Node>());
				ArrayList<Node> chs = new ArrayList<Node>();
				chs.add(ch);
				Node cur = new Node("INT",chs);
				stack.add(cur);
			}
			else if(Character.isLetter(strs[i].charAt(0))){
				Node ch = new Node(strs[i],null);
				ArrayList<Node> chs = new ArrayList<Node>();
				chs.add(ch);
				Node cur = new Node("STR20",chs);
				stack.add(cur);
			}
			else{
// ID = "STUDENT" and remove the ""
				Node ch = new Node(strs[i].substring(1, strs[i].length()-1),new ArrayList<Node>());
				ArrayList<Node> chs = new ArrayList<Node>();
				chs.add(ch);
				Node cur = new Node("Column",chs);
				stack.add(cur);
			}
		}
		while(stack.size() >= 3){
			Node num1 = stack.pop();
			Node operation = stack.pop();
            Node num2 = stack.pop();
            operation.getChildren().add(num1);
            operation.getChildren().add(num2);
            stack.push(operation);
		}		
		return stack.peek();
	}

}
