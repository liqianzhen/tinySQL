import storageManager.*;


public class Where {
	class Temp {
        String type;
        String tempString;
        int tempInteger;
        public boolean equals(Temp t2) {
            if (!this.type.equalsIgnoreCase(t2.type)) return false;
            if(this.type.equals("INT")) {
                return this.tempInteger == t2.tempInteger;
            } else {
                return this.tempString.equals(t2.tempString);
            }
        }
    }
	
	Node where_node;
    public Where(Node where_node) {
        this.where_node = where_node;
    }
    
    
    
    public boolean evaluateBoolean(Tuple tuple) {
    	
    	 
        switch (where_node.getLabel()) {
        //contains where inside where clause
            case "Where":
            {
                
                return new Where(where_node.getChildren().get(0)).evaluateBoolean(tuple);
                
            }
            case "AND": {
                /**
                 * This is the first version, still lot of things to be done <>Push selection done</>
                 */
                return new Where(where_node.getChildren().get(1)).evaluateBoolean(tuple)
                        &&new Where(where_node.getChildren().get(0)).evaluateBoolean(tuple);
            }
            case "OR": {
                return new Where(where_node.getChildren().get(1)).evaluateBoolean(tuple)
                        ||new Where(where_node.getChildren().get(0)).evaluateBoolean(tuple);
            }
            case "=": {
            	Where left = new Where(where_node.getChildren().get(1));
            	Where right = new Where(where_node.getChildren().get(0));
                
                return left.evaluateUnknown(tuple).equals(right.evaluateUnknown(tuple));
            }
            case ">": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        >new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "<": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        <new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "NOT": {
                return !new Where(where_node.getChildren().get(0)).evaluateBoolean(tuple);
            }
            default: try {
                throw new Exception("Unknown Operator");
            }catch (Exception err) {
                err.printStackTrace();
            }
        }
        return false;
    }

	
    public boolean evaluateBoolean2(Tuple tuple) {
    	
 
        switch (where_node.getLabel()) {
        //contains where inside where clause
            case "Where":
            {
                
                return new Where(where_node.getChildren().get(0)).evaluateBoolean2(tuple);
                
            }
            case "AND": {
                /**
                 * This is the first version, still lot of things to be done <>Push selection done</>
                 */
                return new Where(where_node.getChildren().get(1)).evaluateBoolean2(tuple)
                        &&new Where(where_node.getChildren().get(0)).evaluateBoolean2(tuple);
            }
            case "OR": {
                return new Where(where_node.getChildren().get(1)).evaluateBoolean2(tuple)
                        ||new Where(where_node.getChildren().get(0)).evaluateBoolean2(tuple);
            }
            case "=": {
            	Node l = where_node.getChildren().get(1);
            	Node r = where_node.getChildren().get(0);
            	
            	if(l.getChildren().get(0).getLabel().equals("r.a")){
            		r.getChildren().get(0).setLabel("tnaturals.t.a");
            	}
            	else{
            		l.getChildren().get(0).setLabel("tnaturals.t.a");
            	}

            	Where left = new Where(l);
            	Where right = new Where(r);
                
                return left.evaluateUnknown(tuple).equals(right.evaluateUnknown(tuple));
            }
            case ">": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        >new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "<": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        <new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "ANDNOT": {
                return !new Where(where_node.getChildren().get(0)).evaluateBoolean2(tuple);
            }
            default: try {
                throw new Exception("Unknown Operator");
            }catch (Exception err) {
                err.printStackTrace();
            }
        }
        return false;
    }
    
    public Temp evaluateUnknown(Tuple tuple) {
        Temp temp = new Temp();
        if (where_node.getLabel().equalsIgnoreCase("Column")) {
            temp.type = "STRING";
            temp.tempString = where_node.getChildren().get(0).getLabel();
        } else if (where_node.getLabel().equalsIgnoreCase("INT")) {
            temp.type = "INT";
            temp.tempInteger = Integer.parseInt(where_node.getChildren().get(0).getLabel());
        } else if (where_node.getLabel().equalsIgnoreCase("STR20")) {
            String name = where_node.getChildren().get(0).getLabel();
            FieldType type = tuple.getSchema().getFieldType(name);
            if (type == FieldType.INT) {
                temp.type = "INT";
                temp.tempInteger = tuple.getField(name).integer;
            } else {
                temp.type = "STRING";
                temp.tempString = tuple.getField(name).str;
            }
        } else {
            temp.type = "INT";
            temp.tempInteger = evaluateInt(tuple);
        }
        return temp;
    }
    
    public int evaluateInt(Tuple tuple) {
        switch (where_node.getLabel()) {
            case "+": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        + new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "-": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        - new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "*": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        * new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "/": {
                return new Where(where_node.getChildren().get(1)).evaluateInt(tuple)
                        / new Where(where_node.getChildren().get(0)).evaluateInt(tuple);
            }
            case "STR20": {
            	String name = where_node.getChildren().get(0).getLabel();
                return tuple.getField(name).integer;
            }
            case "INT": {
                return Integer.parseInt(where_node.getChildren().get(0).getLabel());
            }
        }
        return 0;
    }
	
	

}
