import storageManager.*;

public class Base {
	MainMemory mm;
	Disk disk;
	SchemaManager sm;
	
	public Base(){
		this.mm = new MainMemory();
		this.disk = new Disk();
		this.sm = new SchemaManager(mm, disk);
	}
}
