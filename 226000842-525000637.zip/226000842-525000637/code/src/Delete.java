import storageManager.*;

import java.util.ArrayList;

public class Delete {
	public void deleteTuple(Statement statement, Base base){
		
		// traverse all the tuples to see whether it is needed to deleted;
		MainMemory mm = base.mm;
		Disk disk = base.disk;
		SchemaManager sm = base.sm;
		//DELETE FROM course 
		String relation_name = statement.getNodes().get(0).getLabel();
		Relation relation = sm.getRelation(relation_name);

		int block_size = relation.getNumOfBlocks();

		//if relation is empty, exit
		if (relation.getNumOfTuples() == 0) {
			return;
		}

		// if there is no where condition
		if (statement.getNodes().size() == 1) {
			for (int i = 0; i < block_size; i++) {
				relation.getBlock(i, 0);
				ArrayList<Tuple> tuples = mm.getTuples(0, 1);
				for (Tuple t : tuples) {
					t.invalidate();
				}
				mm.setTuples(0, tuples);
				relation.setBlock(i, 0);
			}

			return;
		} else {
			//there is where condition, the idea here is to read first block and last block from disk into main memory,
			// and scan first block once a tuple is deleted, use last block tuple to refill that hole.
			// The whole process stop until two pointer meet each other

			//block index in the disk
			int first_block_index = 0;
			int last_block_index = block_size - 1;

			//read them into main memory
			relation.getBlock(0, 0);
			relation.getBlock(last_block_index, 9);

			//get those tuples
			ArrayList<Tuple> tuples_first = mm.getTuples(0, 1);
			ArrayList<Tuple> tuples_last = mm.getTuples(9, 1);


			//tuple index in the block
			int tuple_index_first_block = 0;
			int tuple_index_last_block = mm.getBlock(9).getNumTuples() - 1;

			//where node for evaluation
			Where where_evaluator = new Where(statement.getNodes().get(1));

			while (first_block_index != last_block_index || tuple_index_last_block != tuple_index_first_block) {
				Tuple current_tupe = tuples_first.get(tuple_index_first_block);
				if (where_evaluator.evaluateBoolean(current_tupe)) {
					//Deep copy of tuple from last block
					Tuple temp = new Tuple(tuples_last.get(tuple_index_last_block));
					tuples_last.get(tuple_index_last_block).invalidate();
					tuples_first.set(tuple_index_first_block, temp);
					tuple_index_last_block--;

					//consume all tuple in last block, store this empty block to disk, read in another block from last
					if (tuple_index_last_block < 0) {
						mm.setTuples(9, tuples_last);
						relation.setBlock(last_block_index, 9);
						last_block_index--;
						relation.getBlock(last_block_index, 9);
						tuple_index_last_block = mm.getBlock(9).getNumTuples() - 1;
						tuples_last = mm.getTuples(9, 1);
					}
				} else {
					tuple_index_first_block++;

					//finish scan the first table, store it back to disk, read in another block from first
					if (tuple_index_first_block >= mm.getBlock(0).getNumTuples()) {
						mm.setTuples(0, tuples_first);
						relation.setBlock(first_block_index, 0);
						first_block_index++;
						relation.getBlock(first_block_index, 0);
						tuple_index_first_block = 0;
						tuples_first = mm.getTuples(0, 1);
					}

				}
			}

			//determine the tuple when two point meet each other;
			Tuple currentTuple = tuples_first.get(tuple_index_first_block);
			if (where_evaluator.evaluateBoolean(currentTuple)) {
				currentTuple.invalidate();

				if (tuple_index_first_block == 0) {
					relation.deleteBlocks(first_block_index);
				} else {
					mm.setTuples(0, tuples_first);
					relation.setBlock(first_block_index, 0);
					if (first_block_index + 1 < relation.getNumOfBlocks()) {
						relation.deleteBlocks(first_block_index + 1);
					}
				}
			} else {
				mm.setTuples(0, tuples_first);
				relation.setBlock(first_block_index, 0);
				if (first_block_index + 1 < relation.getNumOfBlocks()) {
					relation.deleteBlocks(first_block_index + 1);
				}
			}

		}





	}
}
