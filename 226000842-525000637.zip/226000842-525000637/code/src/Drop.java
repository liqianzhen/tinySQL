import storageManager.*;
public class Drop {
	
	
	public void dropRelation(Statement statement, Base base){
		
		MainMemory mm = base.mm;
		Disk disk = base.disk;
		SchemaManager sm = base.sm;
		
		String relation_name = statement.getNodes().get(0).getLabel();
		
		
		// black hole
		sm.deleteRelation(relation_name);
        System.out.println("DROP: Successfully drop relation "+ relation_name);
		
		// TODO: BLACKHOLE ISSUE
		
	}

}
