import java.util.ArrayList;
import storageManager.*;

public class Insert {
	

	public void insertTuple(Statement statement,Base base){
		
		
		MainMemory mm = base.mm;
		Disk disk = base.disk;
		SchemaManager sm = base.sm;
		
		// parse the statement into table, attribute, value
		String relation_name = statement.getNodes().get(0).getLabel();
		ArrayList<Node> attrs = statement.getNodes().get(1).getChildren();
		String valueOrSubquery = statement.getNodes().get(2).getLabel();

		// TODO: SELECT - CLUASE

		if (valueOrSubquery.equalsIgnoreCase("select_subquery")) {
			//use select method to get value list
			Statement subquery = new Statement(statement.getNodes().get(2).getChildren());
			// ArrayList<Node> value_list = Select(Statement subquery, schema_manager)
			Relation relation = sm.getRelation(relation_name);

			relation.getBlocks(0,0,relation.getNumOfBlocks());

			// store the result, temporarily store all of the tuples in relation
			ArrayList<Tuple> tuples;
			tuples = mm.getTuples(0, relation.getNumOfBlocks());

			for (Tuple t : tuples) {
				Tools.appendTupleToRelation(relation, mm, 0, t);
			}

		} else {
			//normal add one tuple
			ArrayList<Node> value_list = statement.getNodes().get(2).getChildren();
			if (!sm.relationExists(relation_name)) {
				System.out.println("create the table first");
			} else {
				Relation relation = sm.getRelation(relation_name);
				Tuple tuple = relation.createTuple();
				if (attrs.size() != value_list.size()) {
					System.out.println("number of attributes and values do not match");
				} else {
					for (int i = 0; i < attrs.size(); i++) {
						String attribute_name = attrs.get(i).getLabel();
						String value = value_list.get(i).getLabel();
						if (value.equalsIgnoreCase("null")) {
							continue;
						} else if (value.charAt(0)=='"') {
							tuple.setField(attribute_name, value.substring(1, value.length() - 1));
						} else {
							tuple.setField(attribute_name, Integer.parseInt(value));
						}
					}
				}
				Tools.appendTupleToRelation(relation, mm, 0, tuple);
			}
		}
		
//		int tuple_num_per_block = schema.getTuplesPerBlock();
//
//		// build the tuple to be inserted
//		Tuple tuple =  relation.createTuple();
//		for(int i = 0 ; i < attrs.size(); i++){
//			String field_name = attrs.get(i).getChildren().get(0).getLabel();
//			FieldType type = tuple.getSchema().getFieldType(i);
//			if(type.equals(FieldType.INT)){
//				tuple.setField(i, Integer.parseInt(values.get(i).getLabel()));
//			}
//			else if(type.equals(FieldType.STR20)){
//				tuple.setField(i, values.get(i).getLabel());
//			}
//		}
//
//		if(relation.getNumOfBlocks() ==  0){
//			mm.getBlock(0).clear();
//			mm.getBlock(0).appendTuple(tuple);
//			relation.setBlock(0, 0);
//		}
//		else{
//			int size = relation.getNumOfBlocks();
//
//			relation.getBlock(size-1, 0);
//
//			if(mm.getBlock(0).isFull()){
//				mm.getBlock(0).clear();
//				mm.getBlock(0).appendTuple(tuple);
//				relation.setBlock(size, 0);
//			}
//			else{
//				mm.getBlock(0).appendTuple(tuple);
//				relation.setBlock(size-1, 0);
//			}
//		}
	}
}
