public class testforlintcode {
    public static int maxCoins(int[] nums) {
        if (nums == null || nums.length == 0) {
            return 0;
        }

        int[] numsExpand = new int[nums.length + 2];
        numsExpand[0] = 1;
        for (int i = 0; i < nums.length; i++) {
            numsExpand[i + 1] = nums[i];
        }
        numsExpand[nums.length + 1] = 1;

        int[][] dp = new int[nums.length][nums.length];

        for (int i = 0; i < nums.length; i++) {
            dp[i][i] = numsExpand[i] * numsExpand[i + 1] * numsExpand[i + 2];
        }

        for (int i = 2; i <= nums.length; i++) {
            for (int j = 0; j < nums.length - i + 1; j++) {
                int max = Integer.MIN_VALUE;
                for (int k = 0; k < i; k++) {
                    int temp = numsExpand[j] * numsExpand[j + 1 + k] * numsExpand[j + i + 1];
                    if (k == 0) {
                        max = Math.max(max, dp[j + 1][j + i - 1] + temp);
                    } else if (k == i - 1) {
                        max = Math.max(max, dp[j][j + i - 2] + temp);
                    } else {
                        max = Math.max(max, dp[j][j + k - 1] + dp[j + k + 1][j + i - 1] + temp);
                    }
                }
                dp[j][j + i - 1] = max;
            }
        }

        return dp[0][nums.length - 1];
    }

    public static void main(String[] args) {
        int [] values = {3,1,5};
        testforlintcode.maxCoins(values);
    }
}
