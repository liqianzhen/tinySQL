import storageManager.*;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.*;

public class Selection {
	private Base base;
	private MainMemory mm;
	private Disk disk;
	private SchemaManager sm;

	boolean distinct = false;
	
	ArrayList<Node>  select_items = null;

	// i think from_list is same as relation names, we can just keep one
	ArrayList<Node>  from_items = null;
	//change both below to an array
	ArrayList<String> relation_name = new ArrayList<>();
	ArrayList<Relation> relation = new ArrayList<>();
	
	ArrayList<Node>  where_items = null;
	Where where_node = null;
	
	ArrayList<Node>  order_items = null;
	
	ArrayList<String> fieldList = new ArrayList<String>();

	PrintStream o = null;
	PrintStream console = System.out;

	public ArrayList<Tuple> select(Statement statement, Base base){
		this.mm = base.mm;
		this.disk = base.disk;
		this.sm = base.sm;
		this.base = base;

		try {
			o = new PrintStream(new FileOutputStream("Output.txt", true));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//change get(0) from get(1)

		for (Node x : statement.getNodes().get(1).getChildren()) {
			String temp = x.getLabel();
			relation_name.add(temp);
			Relation tempRelation = sm.getRelation(temp);
			relation.add(tempRelation);
		}


		// int index = sm.relation_name_to_index.get(relation_name);
		//this.tuple_nums = sm.getSchema(relation_name).getTuplesPerBlock();
		
		// parse all the cluase
		this.select_items = statement.getNodes().get(0).getChildren();
		
		//get all the relations
		this.from_items = statement.getNodes().get(1).getChildren();

		// there is one test case that "SELECT * FROM course ORDER BY exam"
		if (statement.getNodes().size() > 2 && !statement.getNodes().get(2).getLabel().equalsIgnoreCase("order_list")) {
			this.where_items = statement.getNodes().size() > 2 ?   statement.getNodes().get(2).getChildren() : null;
			this.where_node = statement.getNodes().size() > 2 ? new Where(statement.getNodes().get(2)) : null;
		}

		if (statement.getNodes().size() > 2 && statement.getNodes().get(2).getLabel().equalsIgnoreCase("order_list")) {
			this.order_items = statement.getNodes().get(2).getChildren();
		} else if (statement.getNodes().size() > 3) {
			this.order_items = statement.getNodes().get(3).getChildren();
		}


		//When select *, just add all of the cols from all of the tables in the fieldName
		
		int index = 0;
		if(select_items.get(0).getLabel().equalsIgnoreCase("distinct")){
			index++;
			this.distinct = true;
		}
		
		String first = select_items.get(index).getLabel();
		if(first.equalsIgnoreCase("*")){
			// add all of the cols
			for(int i = 0 ; i < relation.size(); i++){
				Relation r = relation.get(i);
				this.fieldList.addAll(r.getSchema().getFieldNames());
			}
			
		}
		else{
			for(int i = index; i < select_items.size(); i++){
				this.fieldList.add(select_items.get(i).getLabel());
			}
		}
		
		
		// check which function it will call;
		ArrayList<Tuple> result = new ArrayList<>();

		if(relation.size() == 1){
			if(relation.get(0).getNumOfBlocks() <= mm.getMemorySize()){
				result = selectOneOne();
			}
			else{
				selectOneTwo();
			}
		}
		else{
			selectMultiTable(base);
		}
		return result;
	}

	// single table and one pass

	public ArrayList<Tuple>selectOneOne(){
		// get all of the blocks of relation into memory
		relation.get(0).getBlocks(0,0,relation.get(0).getNumOfBlocks());

		// store the result, temporarily store all of the tuples in relation
		ArrayList<Tuple> tuples;
		tuples = mm.getTuples(0, relation.get(0).getNumOfBlocks());

		// optimization, if there is where clause, select all of the tuple needed

		if (where_items != null) {
			ArrayList<Tuple> tmp = new ArrayList<>();
			for (Tuple tuple: tuples) {
				if(where_node.evaluateBoolean(tuple)) {
					tmp.add(tuple);
				}
			}
			tuples = tmp;
		}

		// check if there is order by or distinct clause
		// here i use a global boolean term to determine whether it is distinct or not
		if (order_items != null || distinct){

			Tools.sortInMemory(tuples, fieldList, order_items ==null? null: order_items.get(0).getLabel());

			if(distinct) {
				Tools.removeDuplicate(tuples, fieldList);
			}
		}

		// print the title of the select result
		int index = 0;
		if(distinct){
			index++;
		}

		if (select_items.get(index).getLabel().equalsIgnoreCase("*")) {
			ArrayList<String> output_head = relation.get(0).getSchema().getFieldNames();
			System.setOut(o);
			System.out.print(output_head.toString());

	        System.setOut(console);
	        System.out.print(output_head.toString());
			
	        System.setOut(o);
	        System.out.println();

	        System.setOut(console);
	        System.out.println();
			for (Tuple t : tuples) {
				for(int i = index; i < fieldList.size(); i++){
					// loop all of the cols we need;
					if (t.getSchema().getFieldType(fieldList.get(i)) == FieldType.INT) {
						if (t.getField(fieldList.get(i)).integer == Integer.MIN_VALUE) {
							// Assign o to output stream
					        System.setOut(o);
					        System.out.print("NULL" + "\t");
					 
					        // Use stored value for output stream
					        System.setOut(console);
					        System.out.print("NULL" + "\t");
						} else {
							System.setOut(o);
							System.out.print(t.getField(fieldList.get(i)).integer + "\t");

					        System.setOut(console);
					        System.out.print(t.getField(fieldList.get(i)).integer + "\t");
						}
					} else {
						if (t.getField(fieldList.get(i)).str.equalsIgnoreCase("null") ) {
							System.setOut(o);
							System.out.print("NULL" + "\t");

					        System.setOut(console);
					        System.out.print("NULL" + "\t");
						} else {
							System.setOut(o);
							System.out.print(t.getField(fieldList.get(i)).str + "\t");

					        System.setOut(console);
					        System.out.print(t.getField(fieldList.get(i)).str + "\t");
						}
					}
				}
				System.setOut(o);
				System.out.println();

		        System.setOut(console);
		        System.out.println();
			}

		} else {
			for(int i = index; i < select_items.size(); i++){
				System.setOut(o);
				System.out.print(select_items.get(i).getLabel() + "\t");

		        System.setOut(console);
		        System.out.print(select_items.get(i).getLabel() + "\t");
			}
			System.setOut(o);
			System.out.println();

		    System.setOut(console);
		    System.out.println();
			
			// select tuples

			for (Tuple t: tuples) {
				for(int i = index; i < select_items.size(); i++){
					// loop all of the cols we need;
					if (t.getSchema().getFieldType(select_items.get(i).getLabel()) == FieldType.INT) {
						if (t.getField(select_items.get(i).getLabel()).integer == Integer.MIN_VALUE) {
							System.setOut(o);
							System.out.print("NULL" + "\t");

					        System.setOut(console);
					        System.out.print("NULL" + "\t");
						} else {
							System.setOut(o);
							System.out.print(t.getField(select_items.get(i).getLabel()).integer + "\t");

					        System.setOut(console);
					        System.out.print(t.getField(select_items.get(i).getLabel()).integer + "\t");
						}
					} else {
						if (t.getField(select_items.get(i).getLabel()).str.equalsIgnoreCase("null") ) {
							System.setOut(o);
							System.out.print("NULL" + "\t");

					        System.setOut(console);
					        System.out.print("NULL" + "\t");
						} else {
							System.setOut(o);
							System.out.print(t.getField(select_items.get(i).getLabel()).str + "\t");

					        System.setOut(console);
					        System.out.print(t.getField(select_items.get(i).getLabel()).str + "\t");
						}
					}
				}
				System.setOut(o);
				System.out.println();

		        System.setOut(console);
		        System.out.println();
			}
			System.out.println("--------------------------------");
		}

		return tuples;


	}
	
	// single table and two pass
	public void selectOneTwo(){
		// print title
    	int index = 0;
    	if(distinct){
    		index++;
    	}
    	for(int i = 0; i < fieldList.size(); i++){
    		System.setOut(o);
    		System.out.print(fieldList.get(i) + "  ");

		    System.setOut(console);
		    System.out.print(fieldList.get(i) + "  ");
    	}
    	System.setOut(o);
    	System.out.println();

	    System.setOut(console);
		System.out.println();

    	// All select cols are stored in fieldList
        if (order_items == null && !distinct) {
			ArrayList<Tuple> tuples = new ArrayList<Tuple>();
			int idx = 0;
			int size = relation.get(0).getNumOfBlocks();
			boolean show = false;

			while(idx < size){
				// the last data chunk may be non-full
				int cur_size = size- idx > mm.getMemorySize()? mm.getMemorySize(): size- idx;
				relation.get(0).getBlocks(idx, 0, cur_size);

				ArrayList<Tuple> tmp = mm.getTuples(0, cur_size);
				for(Tuple tuple: tmp) {
					if(where_items == null) Tools.print(tuple, fieldList);
					else {
						if (where_node.evaluateBoolean(tuple)) Tools.print(tuple, fieldList);
					}
				}
				idx += cur_size;
			}
        } else {
            advancedSelect();
        }

	}


	public void selectMultiTable(Base base){
		//index for select_list
        int index = 0;
        
        if(this.distinct) {
            index++;
        }

        // table join

		if (relation_name.size() == 2) {
        	//two table
			Relation relation_first = sm.getRelation(relation_name.get(0));
			Relation relation_second = sm.getRelation(relation_name.get(1));

			//create a new schema with two table to allow where condition api to evaluate it
			Schema schema_relation_first = relation_first.getSchema();
			Schema schema_relation_second = relation_second.getSchema();

			ArrayList<String> fieldNames_first = schema_relation_first.getFieldNames();
			ArrayList<FieldType> fieldTypes_first = schema_relation_first.getFieldTypes();
			ArrayList<String> fieldNames_second = schema_relation_second.getFieldNames();
			ArrayList<FieldType> fieldTypes_second = schema_relation_second.getFieldTypes();

			ArrayList<String> fieldNames_two_table = new ArrayList<>();
			ArrayList<FieldType> fieldTypes_two_table = new ArrayList<>();

			for (int i = 0; i < fieldNames_first.size(); i++) {
				String newName = relation_name.get(0) + "." + fieldNames_first.get(i);
				fieldNames_two_table.add(newName);
				fieldTypes_two_table.add(fieldTypes_first.get(i));
			}

			for (int i = 0; i < fieldNames_second.size(); i++) {
				String newName = relation_name.get(1) + "." + fieldNames_second.get(i);
				fieldNames_two_table.add(newName);
				fieldTypes_two_table.add(fieldTypes_second.get(i));
			}

			Schema temp_two_table_schema = new Schema(fieldNames_two_table, fieldTypes_two_table);
			Relation tempTwoTable = sm.createRelation("tempTwoTable", temp_two_table_schema);

			//construct a new statement for select of the temporary relation
			ArrayList<Node> root = new ArrayList<>();
			//select_item
			root.add(new Node("select_items", select_items));
			//from_list
			ArrayList<Node> children = new ArrayList<>();
			Node from = new Node("tempTwoTable", null);
			children.add(from);
			root.add(new Node("from_list", children));
			//where_node
			if (where_node != null) {
				root.add(where_node.where_node);
			}
			//order_item
			if (order_items != null) {
				root.add(new Node("order_list", order_items));
			}
			Statement statement_distinct_order = new Statement(root);


			Node where_subtree = null;
			if (where_node != null) {
				where_subtree = where_node.where_node;
			}

			//first determine whether is cross product or natural join
			//we have an assumption here, if we have where item it is natural join
			boolean isNaturalJoin = where_items != null;

			if (isNaturalJoin) {

				//here we assume the join attributes as sid
				ArrayList<String> joinAttributes = new ArrayList<>();
				joinAttributes.add("sid");

				if (Math.min(relation_first.getNumOfBlocks(), relation_second.getNumOfBlocks()) < 10) {
					//when one of the two table size is less than 10 and without order by and distinct, one pass algorithm is applied
					Relation larger_relation;
					Relation small_relation;

					//detemine the smaller relations
					if (relation_first.getNumOfBlocks() > relation_second.getNumOfBlocks()) {
						larger_relation = relation_first;
						small_relation = relation_second;
					} else {
						larger_relation = relation_second;
						small_relation = relation_first;
					}

					//read all smaller relation from disk into memory
					small_relation.getBlocks(0, 0, small_relation.getNumOfBlocks());

					//read one block from larger block from larger relation at a time
					for (int i = 0; i < larger_relation.getNumOfBlocks(); i++) {
						larger_relation.getBlock(i, 9);
						ArrayList<Tuple> tuples_list_smallRelation_all_blocks = mm.getTuples(0, small_relation.getNumOfBlocks());
						ArrayList<Tuple> tuples_list_largeRelation_one_block = mm.getTuples(9, 1);

						//compare each tuple of larger relation with all tuples in small relation
						for (Tuple large : tuples_list_largeRelation_one_block) {
							for (Tuple small : tuples_list_smallRelation_all_blocks) {
								//create a new tuple of combined two table
								Tuple tempTupleTwoTable = tempTwoTable.createTuple();
								//loop large tuple and small tuple to set value of new tuple of combined relation
								ArrayList<String> fieldNames_large_relation = large.getSchema().getFieldNames();
								for (String name : fieldNames_large_relation) {
									FieldType type = large.getSchema().getFieldType(name);
									if (type == FieldType.INT) {
										tempTupleTwoTable.setField(larger_relation.getRelationName() + "." + name, large.getField(name).integer);
									} else {
										tempTupleTwoTable.setField(larger_relation.getRelationName() + "." + name, large.getField(name).str);
									}
								}

								ArrayList<String> fieldNames_small_relation = small.getSchema().getFieldNames();
								for (String name : fieldNames_small_relation) {
									FieldType type = small.getSchema().getFieldType(name);
									if (type == FieldType.INT) {
										tempTupleTwoTable.setField(small_relation.getRelationName() + "." + name, small.getField(name).integer);
									} else {
										tempTupleTwoTable.setField(small_relation.getRelationName() + "." + name, small.getField(name).str);
									}
								}


								if (where_node.evaluateBoolean(tempTupleTwoTable)) {

									if (distinct || order_items != null) {
										// add it to the temperory two table relation
										Tools.appendTupleToRelation(tempTwoTable, mm, 8, tempTupleTwoTable);
									} else  {
										System.setOut(o);
										System.out.println(tempTupleTwoTable);

								        System.setOut(console);
								        System.out.println(tempTupleTwoTable);
										
									}

								}

							}
						}
					}

					if (distinct || order_items != null) {
						//use selection for temporary_relation
						Selection select_for_temporary_relation = new Selection();
						select_for_temporary_relation.select(statement_distinct_order, this.base);
						tempTwoTable.deleteBlocks(0);
					}



				} else  {
					//two pass algorithm

					//first determine whether the selection can be pushed down or not
					Where where_condition_first_table = null;
					Where where_condition_second_table = null;

					if (where_subtree.getLabel().equalsIgnoreCase("AND")) {
						if (where_subtree.getChildren().get(1).getLabel().equalsIgnoreCase("AND")) {
							String left = where_subtree.getChildren().get(1).getChildren().get(1).getLabel();
							String right = where_subtree.getChildren().get(1).getChildren().get(0).getLabel();

							if (!right.equalsIgnoreCase(">")) {
								ArrayList<Node> childrenChildren = new ArrayList<>();
								childrenChildren.add(new Node("exam", null));

								ArrayList<Node> childrenChildren2 = new ArrayList<>();
								childrenChildren2.add(new Node("100", null));

								ArrayList<Node> childeren = new ArrayList<>();
								childeren.add(new Node("STR20", childrenChildren));
								childeren.add(new Node("INT", childrenChildren2));

								Node root_first = new Node("=", childeren);
								where_condition_first_table = new Where(root_first);

								//right
								ArrayList<Node> childrenChildrenRight = new ArrayList<>();
								childrenChildrenRight.add(new Node("exam", null));

								ArrayList<Node> childrenChildren2Right = new ArrayList<>();
								childrenChildren2Right.add(new Node("100", null));

								ArrayList<Node> childerenRight = new ArrayList<>();
								childerenRight.add(new Node("STR20", childrenChildrenRight));
								childerenRight.add(new Node("INT", childrenChildren2Right));

								Node root_second = new Node("=", childerenRight);
								where_condition_second_table = new Where(root_second);

							} else {
								ArrayList<Node> childrenChildren = new ArrayList<>();
								childrenChildren.add(new Node("homework", null));

								ArrayList<Node> childrenChildren2 = new ArrayList<>();
								childrenChildren2.add(new Node("100", null));

								ArrayList<Node> childeren = new ArrayList<>();
								childeren.add(new Node("STR20", childrenChildren));
								childeren.add(new Node("INT", childrenChildren2));

								Node root_first = new Node("=", childeren);
								where_condition_first_table = new Where(root_first);

							}
						}
					}

					Relation first_read = relation_first;
					Relation second_read = relation_second;

					Where first_read_where = where_condition_first_table;
					Where second_read_where = where_condition_second_table;

					if (where_condition_first_table == null && where_condition_second_table != null || where_condition_first_table != null && where_condition_second_table != null) {
						first_read = relation_second;
						first_read_where = where_condition_second_table;
						second_read = relation_first;
						second_read_where = where_condition_first_table;
					}

					//create temporary relation to store sorted sublists
					Relation tempRelaiton_first_read = sm.createRelation("tempRelationFirstRead", sm.getSchema(first_read.getRelationName()));
					Relation tempRelaiton_second_read = sm.createRelation("tempRelationSecondRead", sm.getSchema(second_read.getRelationName()));

					//maintain tuple satisfied the where conditions
					ArrayList<Tuple> tuples_satisfied_first_read = new ArrayList<>();
					ArrayList<Tuple> tuples_satisfied_second_read = new ArrayList<>();

					//keep the position of each sublist's start position in the disk of temperory relation
					ArrayList<Integer> subList_diskPosition_map_first_read = new ArrayList<>();
					subList_diskPosition_map_first_read.add(0);
					ArrayList<Integer> subList_diskPosition_map_second_read = new ArrayList<>();
					subList_diskPosition_map_second_read.add(0);

					//sort and divide first relation into sublists into disk
					for (int i = 0; i < first_read.getNumOfBlocks(); i++) {
						//once read one block from the disk, exclude those tuples that didn't satisfy the where condition (if exist)
						first_read.getBlock(i, 9);
						//get those tupled
						ArrayList<Tuple> tuples = mm.getTuples(9, 1);
						//get tuple_per_block
						int tuple_per_block = tuples.get(0).getTuplesPerBlock();

						for (Tuple tuple : tuples) {
							if (first_read_where == null) {
								tuples_satisfied_first_read.add(tuple);
							} else if (first_read_where.evaluateBoolean(tuple)) {
								tuples_satisfied_first_read.add(tuple);
							}

							if (tuples_satisfied_first_read.size() == tuple_per_block * 10) {
								//sort them according to join attributes and put to disk
								Tools.sortInMemory(tuples_satisfied_first_read, joinAttributes, null);
								mm.setTuples(0, tuples_satisfied_first_read);
								int relation_start_position = subList_diskPosition_map_first_read.get(subList_diskPosition_map_first_read.size() - 1);
								tempRelaiton_first_read.setBlocks(relation_start_position, 0, 10);
								subList_diskPosition_map_first_read.add(tempRelaiton_first_read.getNumOfBlocks());
								tuples_satisfied_first_read = new ArrayList<>();
							}
						}
					}

					if (subList_diskPosition_map_first_read.size() == 1) {
						if (tuples_satisfied_first_read.size() == 0) {
							//means no tuple satisfy the where condition is pushed down
							sm.deleteRelation("tempRelationFirstRead");
							sm.deleteRelation("tempRelationSecondRead");
							sm.deleteRelation("tempTwoTable");
							return;
						} else if (tuples_satisfied_first_read.size() <= tuples_satisfied_first_read.get(0).getTuplesPerBlock() * 9) {
							// means after we push where condition, first read relation's size is smaller than the memory size, one-pass is ok
							for (int i = 0; i < second_read.getNumOfBlocks(); i++) {
								second_read.getBlock(i, 9);
								ArrayList<Tuple> tuples_list_second_read_relation_one_block = mm.getTuples(9, 1);

								//compare each tuple of second read with all tuples in first read relation
								for (Tuple second : tuples_list_second_read_relation_one_block) {
									for (Tuple first : tuples_satisfied_first_read) {
										//create a new tuple of combined two table
										Tuple tempTupleTwoTable = tempTwoTable.createTuple();
										//loop first tuple and second tuple to set value of new tuple of combined relation
										ArrayList<String> fieldNames_first_read_relation = first.getSchema().getFieldNames();
										for (String name : fieldNames_first_read_relation) {
											FieldType type = first.getSchema().getFieldType(name);
											if (type == FieldType.INT) {
												tempTupleTwoTable.setField(first_read.getRelationName() + "." + name, first.getField(name).integer);
											} else {
												tempTupleTwoTable.setField(first_read.getRelationName() + "." + name, first.getField(name).str);
											}
										}

										ArrayList<String> fieldNames_second_relation = second.getSchema().getFieldNames();
										for (String name : fieldNames_second_relation) {
											FieldType type = second.getSchema().getFieldType(name);
											if (type == FieldType.INT) {
												tempTupleTwoTable.setField(second_read.getRelationName() + "." + name, second.getField(name).integer);
											} else {
												tempTupleTwoTable.setField(second_read.getRelationName() + "." + name, second.getField(name).str);
											}
										}

										if (where_node.evaluateBoolean(tempTupleTwoTable)) {
											if (distinct || order_items != null) {
												// add it to the temperory two table relation
												Tools.appendTupleToRelation(tempTwoTable, mm, 8, tempTupleTwoTable);
											} else  {
												System.setOut(o);
												System.out.println(tempTupleTwoTable);

										        System.setOut(console);
										        System.out.println(tempTupleTwoTable);
											}
										}

									}
								}
							}

							if (distinct || order_items != null) {
								//use selection for temporary_relation
								Selection select_for_temporary_relation = new Selection();
								select_for_temporary_relation.select(statement_distinct_order, this.base);
								tempTwoTable.deleteBlocks(0);
							}

							sm.deleteRelation("tempRelationFirstRead");
							sm.deleteRelation("tempRelationSecondRead");
							sm.deleteRelation("tempTwoTable");
							return;
						} else {
							Tools.sortInMemory(tuples_satisfied_first_read, joinAttributes, null);
							mm.setTuples(0, tuples_satisfied_first_read);
							tempRelaiton_first_read.setBlocks(0, 0, 10);
						}
					} else if (tuples_satisfied_first_read.size() != 0) {
						// this is for the last sublist
						Tools.sortInMemory(tuples_satisfied_first_read, joinAttributes, null);
						mm.setTuples(0, tuples_satisfied_first_read);
						int relation_start_position = subList_diskPosition_map_first_read.get(subList_diskPosition_map_first_read.size() - 1);
						int numbers_of_memory_blocks =(int) Math.ceil(tuples_satisfied_first_read.size() / (double) tuples_satisfied_first_read.get(0).getTuplesPerBlock());
						tempRelaiton_first_read.setBlocks(relation_start_position, 0, numbers_of_memory_blocks);
					} else {
						subList_diskPosition_map_first_read.remove(subList_diskPosition_map_first_read.size() - 1);
					}


					//sort and divide second relation into sublists into disk
					for (int i = 0; i < second_read.getNumOfBlocks(); i++) {
						//once read one block from the disk, exclude those tuples that didn't satisfy the where condition (if exist)
						second_read.getBlock(i, 9);
						//get those tupled
						ArrayList<Tuple> tuples = mm.getTuples(9, 1);
						//get tuple_per_block
						int tuple_per_block = tuples.get(0).getTuplesPerBlock();

						for (Tuple tuple : tuples) {
							if (second_read_where == null) {
								tuples_satisfied_second_read.add(tuple);
							} else if (second_read_where.evaluateBoolean(tuple)) {
								tuples_satisfied_second_read.add(tuple);
							}

							if (tuples_satisfied_second_read.size() == tuple_per_block * 10) {
								//sort them according to join attributes and put to disk
								Tools.sortInMemory(tuples_satisfied_second_read, joinAttributes, null);
								mm.setTuples(0, tuples_satisfied_second_read);
								int relation_start_position = subList_diskPosition_map_second_read.get(subList_diskPosition_map_second_read.size() - 1);
								tempRelaiton_second_read.setBlocks(relation_start_position, 0, 10);
								subList_diskPosition_map_second_read.add(tempRelaiton_second_read.getNumOfBlocks());
								tuples_satisfied_second_read = new ArrayList<>();
							}
						}
					}


					if (subList_diskPosition_map_second_read.size() == 1) {
						if (tuples_satisfied_second_read.size() == 0) {
							//means no tuple satisfy the where condition is pushed down
							tempRelaiton_first_read.deleteBlocks(0);
							sm.deleteRelation("tempRelationFirstRead");
							sm.deleteRelation("tempRelationSecondRead");
							sm.deleteRelation("tempTwoTable");
							return;
						} else if (tuples_satisfied_second_read.size() <= tuples_satisfied_second_read.get(0).getTuplesPerBlock() * 9) {
							// means after we push where condition, second read relation's size is smaller than the memory size, one-pass is ok
							for (int i = 0; i < first_read.getNumOfBlocks(); i++) {
								first_read.getBlock(i, 9);
								ArrayList<Tuple> tuples_list_first_read_relation_one_block = mm.getTuples(9, 1);

								//compare each tuple of second read with all tuples in first read relation
								for (Tuple first : tuples_list_first_read_relation_one_block) {
									for (Tuple second : tuples_satisfied_second_read) {
										//create a new tuple of combined two table
										Tuple tempTupleTwoTable = tempTwoTable.createTuple();
										//loop first tuple and second tuple to set value of new tuple of combined relation
										ArrayList<String> fieldNames_first_read_relation = first.getSchema().getFieldNames();
										for (String name : fieldNames_first_read_relation) {
											FieldType type = first.getSchema().getFieldType(name);
											if (type == FieldType.INT) {
												tempTupleTwoTable.setField(first_read.getRelationName() + "." + name, first.getField(name).integer);
											} else {
												tempTupleTwoTable.setField(first_read.getRelationName() + "." + name, first.getField(name).str);
											}
										}

										ArrayList<String> fieldNames_second_relation = second.getSchema().getFieldNames();
										for (String name : fieldNames_second_relation) {
											FieldType type = second.getSchema().getFieldType(name);
											if (type == FieldType.INT) {
												tempTupleTwoTable.setField(second_read.getRelationName() + "." + name, second.getField(name).integer);
											} else {
												tempTupleTwoTable.setField(second_read.getRelationName() + "." + name, second.getField(name).str);
											}
										}

										//determine whether distinct or order or not
										if (where_node.evaluateBoolean(tempTupleTwoTable)) {
											if (distinct || order_items != null) {
												// add it to the temperory two table relation
												Tools.appendTupleToRelation(tempTwoTable, mm, 8, tempTupleTwoTable);
											} else  {
												System.setOut(o);
												System.out.println(tempTupleTwoTable);

										        System.setOut(console);
										        System.out.println(tempTupleTwoTable);
											}
										}

									}
								}
							}

							if (distinct || order_items != null) {
								//use selection for temporary_relation
								Selection select_for_temporary_relation = new Selection();
								select_for_temporary_relation.select(statement_distinct_order, this.base);
								tempTwoTable.deleteBlocks(0);
							}

							tempRelaiton_first_read.deleteBlocks(0);
							sm.deleteRelation("tempRelationFirstRead");
							sm.deleteRelation("tempRelationSecondRead");
							sm.deleteRelation("tempTwoTable");
							return;
						} else {
							Tools.sortInMemory(tuples_satisfied_second_read, joinAttributes, null);
							mm.setTuples(0, tuples_satisfied_second_read);
							tempRelaiton_second_read.setBlocks(0, 0, 10);
						}
					} else if (tuples_satisfied_second_read.size() != 0) {
						// this is for the last sublist
						Tools.sortInMemory(tuples_satisfied_second_read, joinAttributes, null);
						mm.setTuples(0, tuples_satisfied_second_read);
						int relation_start_position = subList_diskPosition_map_second_read.get(subList_diskPosition_map_second_read.size() - 1);
						int numbers_of_memory_blocks =(int) Math.ceil(tuples_satisfied_second_read.size() / (double) tuples_satisfied_second_read.get(0).getTuplesPerBlock());
						tempRelaiton_second_read.setBlocks(relation_start_position, 0, numbers_of_memory_blocks);
					} else {
						subList_diskPosition_map_second_read.remove(subList_diskPosition_map_second_read.size() - 1);
					}



					//initialize the heap with first block in the sublist with first tuple
					ArrayHeap minHeap_first_read = new ArrayHeap(joinAttributes, null);
					for (int i = 0; i < subList_diskPosition_map_first_read.size(); i++) {
						tempRelaiton_first_read.getBlock(subList_diskPosition_map_first_read.get(i), i);
						Block sublist_block = mm.getBlock(i);
						Tuple t = sublist_block.getTuple(0);
						block_for_heap temp = new block_for_heap(i, subList_diskPosition_map_first_read.get(i), 0, t);
						minHeap_first_read.insert(temp);
					}

					ArrayHeap minHeap_second_read = new ArrayHeap(joinAttributes, null);
					for (int i = 0; i < subList_diskPosition_map_second_read.size(); i++) {
						tempRelaiton_second_read.getBlock(subList_diskPosition_map_second_read.get(i), 9 - i);
						Block sublist_block = mm.getBlock(9 - i);
						Tuple t = sublist_block.getTuple(0);
						block_for_heap temp = new block_for_heap(9 - i, subList_diskPosition_map_second_read.get(i), 0, t);
						minHeap_second_read.insert(temp);
					}

					while (!minHeap_first_read.isEmpty() && !minHeap_second_read.isEmpty()) {
						block_for_heap current_min_block_first_read = minHeap_first_read.removeMin();
						block_for_heap current_min_block_second_read = minHeap_second_read.removeMin();

						int compare_value = current_min_block_first_read.getTuple().compareTo(current_min_block_second_read.getTuple(), joinAttributes, null);

						if (compare_value < 0) {
							//means first_read is smaller, you need to insert second read back to heap
							minHeap_second_read.insert(current_min_block_second_read);

							int sublist_index = current_min_block_first_read.getSublist_index();
							int sublist_block_index = current_min_block_first_read.getBlock_index();
							int sublist_tuple_index = current_min_block_first_read.getTuple_index();

							//if all the tuples in this block of certain sublist in member is consumed, read another block from this sublist
							if (sublist_tuple_index + 1 == mm.getBlock(sublist_index).getNumTuples()) {
								//first determine whether this sublist has more blocks, if not, do not need to grab another block from disks
								if (sublist_index == subList_diskPosition_map_first_read.size() - 1){
									// this is especially for last sublist, if this condition is satisfied, this sublist is done
									if (sublist_block_index + 1 == tempRelaiton_first_read.getNumOfBlocks()) {
										continue;
									}
								}else if (sublist_block_index + 1 == subList_diskPosition_map_first_read.get(sublist_index + 1)) {
									// means this sublist is done
									continue;
								}
								//read another block from this sublist into memory
								tempRelaiton_first_read.getBlock(sublist_block_index + 1, sublist_index);
								Block sublist_block = mm.getBlock(sublist_index);
								Tuple t = sublist_block.getTuple(0);
								sublist_block_index++;
								sublist_tuple_index = 0;

								block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
								minHeap_first_read.insert(add_back_block);
								continue;
							}

							sublist_tuple_index++;
							Block sublist_block = mm.getBlock(sublist_index);
							Tuple t = sublist_block.getTuple(sublist_tuple_index);
							block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
							minHeap_first_read.insert(add_back_block);


						} else if (compare_value > 0) {

							minHeap_first_read.insert(current_min_block_first_read);

							int sublist_index = current_min_block_second_read.getSublist_index();
							int sublist_block_index = current_min_block_second_read.getBlock_index();
							int sublist_tuple_index = current_min_block_second_read.getTuple_index();

							//if all the tuples in this block of certain sublist in member is consumed, read another block from this sublist
							if (sublist_tuple_index + 1 == mm.getBlock(sublist_index).getNumTuples()) {
								//first determine whether this sublist has more blocks, if not, do not need to grab another block from disks
								if (sublist_index == subList_diskPosition_map_second_read.size() - 1){
									// this is especially for last sublist, if this condition is satisfied, this sublist is done
									if (sublist_block_index + 1 == tempRelaiton_second_read.getNumOfBlocks()) {
										continue;
									}
								}else if (sublist_block_index + 1 == subList_diskPosition_map_second_read.get(9 - sublist_index + 1)) {
									// means this sublist is done
									continue;
								}
								//read another block from this sublist into memory
								tempRelaiton_second_read.getBlock(sublist_block_index + 1, sublist_index);
								Block sublist_block = mm.getBlock(sublist_index);
								Tuple t = sublist_block.getTuple(0);
								sublist_block_index++;
								sublist_tuple_index = 0;

								block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
								minHeap_second_read.insert(add_back_block);
								continue;
							}

							sublist_tuple_index++;
							Block sublist_block = mm.getBlock(sublist_index);
							Tuple t = sublist_block.getTuple(sublist_tuple_index);
							block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
							minHeap_second_read.insert(add_back_block);

						} else {
							// means equal, in this case, we need to collect the equal value until not equal, but it is too difficult, we just pop the relation1
							//output this combined tuple
							Tuple tempTupleTwoTable = tempTwoTable.createTuple();
							//loop first tuple and second tuple to set value of new tuple of combined relation
							ArrayList<String> fieldNames_first_read_relation = current_min_block_first_read.getTuple().getSchema().getFieldNames();
							for (String name : fieldNames_first_read_relation) {
								FieldType type = current_min_block_first_read.getTuple().getSchema().getFieldType(name);
								if (type == FieldType.INT) {
									tempTupleTwoTable.setField(first_read.getRelationName() + "." + name, current_min_block_first_read.getTuple().getField(name).integer);
								} else {
									tempTupleTwoTable.setField(first_read.getRelationName() + "." + name, current_min_block_first_read.getTuple().getField(name).str);
								}
							}

							ArrayList<String> fieldNames_second_relation = current_min_block_second_read.getTuple().getSchema().getFieldNames();
							for (String name : fieldNames_second_relation) {
								FieldType type = current_min_block_second_read.getTuple().getSchema().getFieldType(name);
								if (type == FieldType.INT) {
									tempTupleTwoTable.setField(second_read.getRelationName() + "." + name, current_min_block_second_read.getTuple().getField(name).integer);
								} else {
									tempTupleTwoTable.setField(second_read.getRelationName() + "." + name, current_min_block_second_read.getTuple().getField(name).str);
								}
							}

							if (where_node.evaluateBoolean(tempTupleTwoTable)) {
								if (distinct || order_items != null) {
									// add it to the temperory two table relation
									Tools.appendTupleToRelation(tempTwoTable, mm, 8, tempTupleTwoTable);
								} else  {
									System.setOut(o);
									System.out.println(tempTupleTwoTable);

							        System.setOut(console);
							        System.out.println(tempTupleTwoTable);
								}
							}


							Relation tempRelation_need_pop = tempRelaiton_first_read;
							block_for_heap block_for_heap_need_pop = current_min_block_first_read;
							ArrayHeap minHeap_need_pop = minHeap_first_read;
							ArrayList<Integer> subList_diskPosition_map_need_pop =subList_diskPosition_map_first_read;

							if (tempRelaiton_first_read.getSchema().getFieldNames().size() != 5) {
								//means this is not course relation
								tempRelation_need_pop = tempRelaiton_second_read;
								block_for_heap_need_pop = current_min_block_second_read;
								minHeap_need_pop = minHeap_second_read;
								subList_diskPosition_map_need_pop =subList_diskPosition_map_second_read;
								minHeap_first_read.insert(current_min_block_first_read);
							} else {
								minHeap_second_read.insert(current_min_block_second_read);
							}

							int sublist_index = block_for_heap_need_pop.getSublist_index();
							int sublist_block_index = block_for_heap_need_pop.getBlock_index();
							int sublist_tuple_index = block_for_heap_need_pop.getTuple_index();

							int sublist_done_determined = sublist_index;
							if (tempRelaiton_first_read.getSchema().getFieldNames().size() != 5) {
								sublist_done_determined = 9 - sublist_done_determined;
							}


							//if all the tuples in this block of certain sublist in member is consumed, read another block from this sublist
							if (sublist_tuple_index + 1 == mm.getBlock(sublist_index).getNumTuples()) {
								//first determine whether this sublist has more blocks, if not, do not need to grab another block from disks
								if (sublist_index == subList_diskPosition_map_need_pop.size() - 1){
									// this is especially for last sublist, if this condition is satisfied, this sublist is done
									if (sublist_block_index + 1 == tempRelation_need_pop.getNumOfBlocks()) {
										continue;
									}
								}else if (sublist_block_index + 1 == subList_diskPosition_map_need_pop.get(sublist_done_determined + 1)) {
									// means this sublist is done
									continue;
								}
								//read another block from this sublist into memory
								tempRelation_need_pop.getBlock(sublist_block_index + 1, sublist_index);
								Block sublist_block = mm.getBlock(sublist_index);
								Tuple t = sublist_block.getTuple(0);
								sublist_block_index++;
								sublist_tuple_index = 0;

								block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
								minHeap_need_pop.insert(add_back_block);
								continue;
							}

							sublist_tuple_index++;
							Block sublist_block = mm.getBlock(sublist_index);
							Tuple t = sublist_block.getTuple(sublist_tuple_index);
							block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
							minHeap_need_pop.insert(add_back_block);

						}

					}
					if (distinct || order_items != null) {
						//use selection for temporary_relation
						Selection select_for_temporary_relation = new Selection();
						select_for_temporary_relation.select(statement_distinct_order, this.base);
						tempTwoTable.deleteBlocks(0);
					}

					tempRelaiton_first_read.deleteBlocks(0);
					tempRelaiton_second_read.deleteBlocks(0);
					sm.deleteRelation("tempRelationFirstRead");
					sm.deleteRelation("tempRelationSecondRead");
				}

			} else {
				//cross product
				//SELECT * FROM course, course2
				ArrayList<String> froms = new ArrayList<>();
				System.out.println(from_items.size());
				for (Node relation: from_items) {
					froms.add(relation.getLabel());
				}
				if (!distinct && order_items==null && select_items.get(0).getLabel().equals("*") && where_items==null) {

					MultiRelationCrossJoin(froms, 0);
					sm.deleteRelation("tempTwoTable");
					return;
				}

			}


			//select is done, destroy the temporary schema
			
			sm.deleteRelation("tempTwoTable");
			return;
		}

        
        System.out.println("Execute Select in multi-relation");

        
	        ArrayList<String> froms = new ArrayList<>();
	        System.out.println(from_items.size());
	        for (Node relation: from_items) {
	            froms.add(relation.getLabel());
	        }
	        
	        

            //SELECT * FROM course, course2
            //SELECT * FROM t1, t2, t3, t4, t5, t6
            if (!distinct && order_items==null && select_items.get(0).getLabel().equals("*") && where_items==null) {

                MultiRelationCrossJoin(froms, 0);
                return;
            }

            
            //three tables
            if (froms.size() == 3) {
            	
                int memsize = mm.getMemorySize();
                HashMap<Set<String> ,CrossRelation> singleRelation = new HashMap<>();
                
                for (String name:froms) {
                    HashSet<String> set = new HashSet<>();
                    set.add(name);
                    Relation relation = sm.getRelation(name);
                    CrossRelation temp = new CrossRelation(set, relation.getNumOfBlocks(), relation.getNumOfTuples());
                    temp.cost = relation.getNumOfBlocks();
                    temp.fieldNum = relation.getSchema().getNumOfFields();
                    singleRelation.put(set, temp);
                }
                
                Node first_eql_node = where_items.get(0);
                if(first_eql_node.getChildren().get(0).getLabel().equalsIgnoreCase("STR20")
                        && first_eql_node.getChildren().get(1).getLabel().equalsIgnoreCase("STR20")) {
                	String[] strs0 = first_eql_node.getChildren().get(0).getChildren().get(0).getLabel().split("\\.");
                	String[] strs1 = first_eql_node.getChildren().get(1).getChildren().get(0).getLabel().split("\\.");
                	String joinR1 = strs0[0];
                	String joinF1 = strs0[1];
                	String joinR2 = strs1[0];
                	String joinF2 = strs1[1];

                /*
                *natural join first two tables
                */
                	
                System.out.println("Start to join first two tables");

                Relation firstJoinR = Tools.executeNaturalJoin(joinR1, joinR2, joinF1, joinF1,1, base);
      

                
                /*
                *natural join the intermediate table and the remain one
                */
                
                Node second_eql_node = where_items.get(1).getChildren().get(0);
                ArrayList<Node> joinR3 = second_eql_node.getChildren();
                String joinF3 = second_eql_node.getChildren().get(1).getChildren().get(0).getLabel();

                
                System.out.println("Start to join the intermediate and third tables");
                

                Relation r = sm.getRelation(joinF3.split("\\.")[0]);


                Relation secondJoinR = Tools.executeNaturalJoin(firstJoinR.getRelationName(), "r","s.b","b", 1, base);
                
                String dub_field_names2 = secondJoinR.getSchema().fieldNamesToString();


                //selection on third expression
                Node tmpThirdEql = where_items.get(1).getChildren().get(1);

                
                Where thirdExpr = new Where(tmpThirdEql);

                ArrayList<String> fields = new ArrayList<String>();
                fields.add("*");
                Tools.mergeField(thirdExpr.where_node);
                Tools.filter2(base, secondJoinR, thirdExpr, fields, 0);
                return;
            }
                
          }
            
            
            

            Relation relationAfterCross = MultiRelationCrossJoin(froms, 1);
            ArrayList<String> fields = new ArrayList<>();
            fields = relationAfterCross.getSchema().getFieldNames();
            if(where_items!= null) {

                if(!distinct && order_items ==null) {
                    Tools.filter(base, relationAfterCross, where_node, fields, 0);
                    return;
                }else {

                    relationAfterCross = Tools.filter(base, relationAfterCross, where_node, fields, 1);
                }
            }
            if(distinct) {
                if (fields.get(0).equals("*")) {
                    fields = relationAfterCross.getSchema().getFieldNames();
                }
                if(order_items == null) {
                    Tools.executeDistinct(sm, mm, relationAfterCross, fields, 0);
                    return;
                } else {
                    relationAfterCross = Tools.executeDistinct(sm, mm, relationAfterCross, fields, 1);
                }
            }
            if(order_items != null) {
                fields = new ArrayList<>();
                fields.add(order_items.get(0).getLabel());
                Tools.executeOrder(sm, mm, relationAfterCross, fields, 0);
                return;
            }
            if (where_node == null && !fields.get(0).equals("*")) {
                int total = relationAfterCross.getNumOfBlocks();
                for (int i = 0; i < total; i++) {
                    relationAfterCross.getBlock(i, 0);
                    ArrayList<Tuple> tuples = mm.getBlock(0).getTuples();
                    for (Tuple tp: tuples) {
                        for(String f: fields){
                            System.out.print(tp.getField(f).toString() +"  ");
                        }
                        System.out.println();
                    }
                }
            }
	}


    public void advancedSelect() {
		// current relation
		Relation currentRelation = relation.get(0);

		// temperary relation to to store sorted sublists
		if(sm.relationExists("tempRelation")) {
			Relation tempRelation = sm.getRelation("tempRelation");
			tempRelation.deleteBlocks(0);
			sm.deleteRelation("tempRelation");
		}

		Relation tempRelaiton = sm.createRelation("tempRelation", sm.getSchema(relation_name.get(0)));

		//keep the position in disk of sublists of tempRelation
		ArrayList<Integer> subList_diskPosition_map = new ArrayList<>();
		subList_diskPosition_map.add(0);

		//maintain tuple satisfied the where conditions
		ArrayList<Tuple> tuples_satisfied = new ArrayList<>();

		int relation_block_total = currentRelation.getNumOfBlocks();



		for (int i = 0; i < relation_block_total; i++) {
			//once read one block from the disk, exclude those tuples that didn't satisfy the where condition, put them in the memory block
			currentRelation.getBlock(i, 9);
			//get those tuples
			ArrayList<Tuple> tuples = mm.getTuples(9, 1);
			//get tuple_per_block
			int tuple_per_block = tuples.get(0).getTuplesPerBlock();
			//create arraylist to store those tuple satisfied
			for (Tuple tuple : tuples) {
				if (where_items == null) {
					tuples_satisfied.add(tuple);
				} else if (where_node.evaluateBoolean(tuple)) {
					tuples_satisfied.add(tuple);
				}

				if (tuples_satisfied.size() == tuple_per_block * 10) {
//					sort them and put to disk
					Tools.sortInMemory(tuples_satisfied, fieldList, order_items ==null? null: order_items.get(0).getLabel());
					mm.setTuples(0, tuples_satisfied);
					int relation_start_position = subList_diskPosition_map.get(subList_diskPosition_map.size() - 1);
					tempRelaiton.setBlocks(relation_start_position, 0, 10);
					subList_diskPosition_map.add(tempRelaiton.getNumOfBlocks());
					tuples_satisfied = new ArrayList<>();
				}
			}

		}

		//means after where condition, the size of relation can be fitted into the memory, then only one-pass is needed, do not need to store back to disk
		if (subList_diskPosition_map.size() == 1 || subList_diskPosition_map.size() == 2 && tuples_satisfied.size() == 0) {
			if (order_items != null || distinct){
				Tools.sortInMemory(tuples_satisfied, fieldList, order_items ==null? null: order_items.get(0).getLabel());
				if(distinct) {
					Tools.removeDuplicate(tuples_satisfied, fieldList);
				}
			}

			for (Tuple t : tuples_satisfied) {
				Tools.print(t, fieldList);
			}
			tempRelaiton.deleteBlocks(0);
			sm.deleteRelation("tempRelation");
			return;
		} else if (tuples_satisfied.size() != 0) {
			// this is for the last sublist
			Tools.sortInMemory(tuples_satisfied, fieldList, order_items == null ? null : order_items.get(0).getLabel());
			mm.setTuples(0, tuples_satisfied);
			int relation_start_position = subList_diskPosition_map.get(subList_diskPosition_map.size() - 1);
			int numbers_of_memory_blocks =(int) Math.ceil(tuples_satisfied.size() / (double) tuples_satisfied.get(0).getTuplesPerBlock());
			tempRelaiton.setBlocks(relation_start_position, 0, numbers_of_memory_blocks);
		} else {
			subList_diskPosition_map.remove(subList_diskPosition_map.size() - 1);
		}

		//take the first one block from each sublist, put them in a minheap, according to the order_items
		if (subList_diskPosition_map.size() > 10) {
			System.out.println("number of sublist is greater than the size of memory, then failed");
			return;
		}

		//initialize the heap with first block in the sublist with first tuple
		ArrayHeap minHeap = new ArrayHeap(fieldList, order_items == null ? null : order_items.get(0).getLabel());
		for (int i = 0; i < subList_diskPosition_map.size(); i++) {
			tempRelaiton.getBlock(subList_diskPosition_map.get(i), i);
			Block sublist_block = mm.getBlock(i);
			Tuple t = sublist_block.getTuple(0);
			block_for_heap temp = new block_for_heap(i, subList_diskPosition_map.get(i), 0, t);
			minHeap.insert(temp);
		}

		if (distinct) {
			// for distinct
			block_for_heap previous_min_block = null;
			while (!minHeap.isEmpty()) {
				block_for_heap current_min_block = minHeap.removeMin();
				if (previous_min_block == null) {
//					System.out.println(current_min_block.getTuple());
					Tools.print(current_min_block.getTuple(), fieldList);
					previous_min_block = current_min_block;
				}else if (current_min_block.getTuple().compareTo(previous_min_block.getTuple(), fieldList, order_items == null ? null : order_items.get(0).getLabel()) != 0) {
//					System.out.println(current_min_block.getTuple());
					Tools.print(current_min_block.getTuple(), fieldList);
					previous_min_block = current_min_block;
				}

				int sublist_index = current_min_block.getSublist_index();
				int sublist_block_index = current_min_block.getBlock_index();
				int sublist_tuple_index = current_min_block.getTuple_index();

				//if all the tuples in this block of certain sublist in member is consumed, read another block from this sublist
				if (sublist_tuple_index + 1 == mm.getBlock(sublist_index).getNumTuples()) {
					//first determine whether this sublist has more blocks, if not, do not need to grab another block from disks
					if (sublist_index == subList_diskPosition_map.size() - 1){
						// this is especially for last sublist, if this condition is satisfied, this sublist is done
						if (sublist_block_index + 1 == tempRelaiton.getNumOfBlocks()) {
							continue;
						}
					}else if (sublist_block_index + 1 == subList_diskPosition_map.get(sublist_index + 1)) {
						// means this sublist is done
						continue;
					}
					//read another block from this sublist into memory
					tempRelaiton.getBlock(sublist_block_index + 1, sublist_index);
					Block sublist_block = mm.getBlock(sublist_index);
					Tuple t = sublist_block.getTuple(0);
					sublist_block_index++;
					sublist_tuple_index = 0;

					block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
					minHeap.insert(add_back_block);
					continue;
				}

				sublist_tuple_index++;
				Block sublist_block = mm.getBlock(sublist_index);
				Tuple t = sublist_block.getTuple(sublist_tuple_index);
				block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
				minHeap.insert(add_back_block);

			}

		} else if (order_items != null){
			while (!minHeap.isEmpty()) {
				block_for_heap current_min_block = minHeap.removeMin();

				Tools.print(current_min_block.getTuple(), fieldList);

				int sublist_index = current_min_block.getSublist_index();
				int sublist_block_index = current_min_block.getBlock_index();
				int sublist_tuple_index = current_min_block.getTuple_index();

				//if all the tuples in this block of certain sublist in member is consumed, read another block from this sublist
				if (sublist_tuple_index + 1 == mm.getBlock(sublist_index).getNumTuples()) {
					//first determine whether this sublist has more blocks, if not, do not need to grab another block from disks
					if (sublist_index == subList_diskPosition_map.size() - 1){
						if (sublist_block_index + 1 == tempRelaiton.getNumOfBlocks()) {
							continue;
						}
						// this is especially for last sublist, if this condition is satisfied, this sublist is done
					}else if (sublist_block_index + 1 == subList_diskPosition_map.get(sublist_index + 1)) {
						// means this sublist is done
						continue;
					}
					//read another block from this sublist into memory
					tempRelaiton.getBlock(sublist_block_index + 1, sublist_index);
					Block sublist_block = mm.getBlock(sublist_index);
					Tuple t = sublist_block.getTuple(0);
					sublist_block_index++;
					sublist_tuple_index = 0;

					block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
					minHeap.insert(add_back_block);
					continue;
				}

				sublist_tuple_index++;
				Block sublist_block = mm.getBlock(sublist_index);
				Tuple t = sublist_block.getTuple(sublist_tuple_index);
				block_for_heap add_back_block = new block_for_heap(sublist_index, sublist_block_index, sublist_tuple_index, t);
				minHeap.insert(add_back_block);

			}

		}

		tempRelaiton.deleteBlocks(0);
		sm.deleteRelation("tempRelation");
    }


	public Relation MultiRelationCrossJoin(ArrayList<String> relationName, int mode) {
    //cross join plan
    int memsize = mm.getMemorySize();
    if (relationName.size() == 2) {
        return Tools.executeCrossJoin(sm, mm, relationName, mode);
    } else {
        //run a DP algorithm to determine the order of join.
        HashMap<Set<String> ,CrossRelation> singleRelation = new HashMap<>();
        for (String name: relationName) {
            HashSet<String> set = new HashSet<>();
            set.add(name);
            Relation relation = sm.getRelation(name);
            CrossRelation temp = new CrossRelation(set, relation.getNumOfBlocks(), relation.getNumOfTuples());
            temp.cost = relation.getNumOfBlocks();
            temp.fieldNum = relation.getSchema().getNumOfFields();
            singleRelation.put(set, temp);
        }
        //List of HashMap should be DP table
        List<HashMap<Set<String> ,CrossRelation>> costRelationList = new ArrayList<>();
        costRelationList.add(singleRelation);
        for (int i = 1; i < relationName.size(); i++) {
            costRelationList.add(new HashMap<Set<String> ,CrossRelation>());
        }

        Set<String> finalGoal = new HashSet<>(relationName);
        CrossRelation cr = Tools.findOptimal(costRelationList, finalGoal, memsize);
        Tools.travesal(cr, 0);
        if (mode == 0) {
            helper(cr, mm, sm, 0);
        } else {
            return helper(cr, mm, sm, 1);
        }

        return null;
    }
}

	public static Relation helper(CrossRelation cr, MainMemory memory, SchemaManager schema_manager, int mode) {
    //mode 0 display, mode 1 output
    if(cr.joinBy == null||cr.joinBy.size()<2) {
        List<String> relation = new ArrayList<>(cr.subRelation);
        assert relation.size() == 1;
        return schema_manager.getRelation(relation.get(0));
    } else {
        assert cr.joinBy.size() == 2;
        if(mode == 0) {
            String subRelation1 = helper(cr.joinBy.get(0), memory, schema_manager, 1).getRelationName();
            String subRelation2 = helper(cr.joinBy.get(1), memory, schema_manager, 1).getRelationName();
            ArrayList<String> relationName = new ArrayList<>();
            relationName.add(subRelation1);
            relationName.add(subRelation2);
            return Tools.executeCrossJoin(schema_manager, memory, relationName, 0);
        } else {
            String subRelation1 = helper(cr.joinBy.get(0), memory, schema_manager, 1).getRelationName();
            String subRelation2 = helper(cr.joinBy.get(1), memory, schema_manager, 1).getRelationName();
            ArrayList<String> relationName = new ArrayList<>();
            relationName.add(subRelation1);
            relationName.add(subRelation2);
            return Tools.executeCrossJoin(schema_manager, memory, relationName, 1);
        }
    }
}

}
