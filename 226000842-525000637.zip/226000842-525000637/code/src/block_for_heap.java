import storageManager.Tuple;

public class block_for_heap {
    public int sublist_index;
    public int block_index;
    public int tuple_index;
    public Tuple tuple;
    public block_for_heap(int sublist_index, int block_index, int tuple_index, Tuple tuple) {
        this.sublist_index = sublist_index;
        this.block_index = block_index;
        this.tuple_index = tuple_index;
        this.tuple = tuple;
    }

    public int getSublist_index() {
        return sublist_index;
    }

    public int getBlock_index() {
        return block_index;
    }

    public int getTuple_index() {
        return tuple_index;
    }

    public Tuple getTuple() {
        return tuple;
    }
}
