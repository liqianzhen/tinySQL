import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Base base = new Base();
        Main sql = new Main();
        File file = sql.getFile("text.txt");

        base.disk.resetDiskIOs();
        base.disk.resetDiskTimer();
        long start = System.currentTimeMillis();
        //construct the Executor
        try (Scanner scanner = new Scanner(file)) {
            int i = 0;
            while (scanner.hasNextLine()) {
            	i++;
            	System.out.println("this is the number of line: " + i);
                //deal with every line
                String line = scanner.nextLine();
                //parse every statement
                Parser parser = new Parser();
                Statement statement = parser.parse(line);

                if(line.split(" ")[0].equalsIgnoreCase("create")) {
                    Create create_executor = new Create();
                    create_executor.createRelation(statement, base);
                } else if (line.split(" ")[0].equalsIgnoreCase("drop")) {
                    Drop drop_executor = new Drop();
                    drop_executor.dropRelation(statement, base);
                } else if (line.split(" ")[0].equalsIgnoreCase("insert")) {
                    Insert insert = new Insert();
                    insert.insertTuple(statement, base);
                } else if (line.split(" ")[0].equalsIgnoreCase("select")) {
                    Selection select = new Selection();
                    select.select(statement, base);
                }else if (line.split(" ")[0].equalsIgnoreCase("delete")) {
                    Delete delete_executor = new Delete();
                    delete_executor.deleteTuple(statement, base);
                }
                
            }

            System.out.println();
            long elapsedTimeMillis = System.currentTimeMillis()-start;
            System.out.print("Simulated elapse time = " + elapsedTimeMillis + " ms" + "\n");
            System.out.print("Simulated Disk I/Os = " + base.disk.getDiskIOs() + "\n");


            scanner.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private File getFile(String fileName) {
        //Get file from resources folder
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(fileName).getFile());
        return file;
    }
}
